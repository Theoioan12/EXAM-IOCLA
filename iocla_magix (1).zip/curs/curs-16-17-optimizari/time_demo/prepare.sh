export PAPI_DIR=/home/razvan/projects/papi/src    # replace this with your path to papi
export LD_LIBRARY_PATH=$PAPI_DIR:$LD_LIBRARY_PATH
export PATH=$PAPI_DIR/utils:$PATH
