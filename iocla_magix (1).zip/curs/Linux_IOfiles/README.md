Macros and library needed to compile examples from the textbook (Dandamudi). 
