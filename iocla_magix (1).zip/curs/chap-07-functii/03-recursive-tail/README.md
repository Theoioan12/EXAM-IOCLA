
Examine code generated for regular recursion versus tail recursion. 

https://gcc.godbolt.org/ using: 
-m32 -march=native 
-O1 or -O2 

