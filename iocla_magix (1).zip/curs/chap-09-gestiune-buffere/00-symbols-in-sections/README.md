
1. linker error: ana is implicitly global; make one static 
2. 
