
1. Apelați funcția alpha() din fișierul diggers.o pentru a afișa șirul Eureka!

2. Apelați funcția beta() din fișierul diggers.o pentru a întoarce numărul 6699

3. Apelați funcția omega() din fișierul diggers.o pentru a afișa șirul ...
 "It has finally happened!"

