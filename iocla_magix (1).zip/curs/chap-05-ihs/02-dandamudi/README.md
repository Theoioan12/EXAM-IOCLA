See Dandamudi Chapter 7, page 219

string.asm functions weere originally implemented with x86 string functions, as în the Dandamudi textbook. 

The first two functions (str_len and str_cpy) have alternative implementations without x86 string functions, but if you want to use the original Dandamudi code, enable the  %define	CISCSTRINGS 1 at the top   

