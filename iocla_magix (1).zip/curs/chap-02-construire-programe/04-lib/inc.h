#ifndef INC_H_
#define INC_H_	1

void init(void);
void increment(void);
unsigned int read(void);

#endif
