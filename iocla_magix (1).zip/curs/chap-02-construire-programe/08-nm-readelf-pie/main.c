/*int sum(int a, int b)
{
	return 17;
}
*/

int main(void)
{
	sum(1,2);
	diff(3,1);
	puts("ana are mere");

	return 0;
}
