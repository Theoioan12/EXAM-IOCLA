extern unsigned int num_items;

void increment(void)
{
	num_items++;
}
