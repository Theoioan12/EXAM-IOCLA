#ifndef FIBONACCI_H
#define FIBONACCI_H_		1

#define FIBO_LIMIT	40

unsigned int fibonacci(unsigned int num);
unsigned int fibonacci_iter(unsigned int num);

#endif
