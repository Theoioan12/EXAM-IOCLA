
Task: în fișierul Makefile,
ștergeti opțiunea -m32 de la compilare și linkare (CFLAGS si LDFLAGS).
În acest mod se va compila pentru 64 de biți. Comparați outputul lui
inspect_vars 32biți vs 64biți.

