#include <stdio.h>

int age;

void print_age(void)
{
	printf("age: %d\n", age);
}
