#include <stdio.h>
#include "ops.h"

int main(void)
{
	printf("mul(10, 5): %d\n", mul(10, 5));
	printf("div(10, 5): %d\n", div(10, 5));

	return 0;
}
