#ifndef OPS_H_
#define OPS_H_		1

int mul(int a, int b);
int div(int a, int b);

#endif
