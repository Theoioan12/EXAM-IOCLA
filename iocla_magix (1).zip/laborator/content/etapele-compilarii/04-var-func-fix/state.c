const char *init_shopping[3];

void shopping_list(void)
{
	init_shopping[0] = "cheese";
	init_shopping[1] = "wine";
	init_shopping[2] = "dessert";
}
