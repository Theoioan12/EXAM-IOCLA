/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

int a;
int b = 10;
char d;
unsigned short array[3] = {10, 20, 30};
char v[100];
char *s = "Nicolae Guta";
const int c = 10;
static int stat = 40;

int f(void)
{
    return 0;
}


int main(void)
{

    return 0;
}
