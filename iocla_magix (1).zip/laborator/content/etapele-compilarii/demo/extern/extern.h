int var=20;
