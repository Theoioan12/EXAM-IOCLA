/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

extern int var = 0;
int main(void)
{
	var = 10;
	return 0;
}

