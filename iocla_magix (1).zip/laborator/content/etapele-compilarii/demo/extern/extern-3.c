/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

extern int var;
int main(void)
{
	var = 10;
	return 0;
}
