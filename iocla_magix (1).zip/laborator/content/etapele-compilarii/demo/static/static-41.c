/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

int var = 10;

void print_hello()
{
	puts("Hello");
}
