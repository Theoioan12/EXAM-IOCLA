/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

#include <stdio.h>
extern int var;

int main() {

	print_hello();
	printf("var = %d\n",var);
	return 0;
}
