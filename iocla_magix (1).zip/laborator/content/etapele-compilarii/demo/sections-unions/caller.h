#ifndef CALLER_H_
#define CALLER_H_

int f(int);

#endif

