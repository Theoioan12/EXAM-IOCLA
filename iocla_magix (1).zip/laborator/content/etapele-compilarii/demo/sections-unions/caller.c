/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

#include "caller.h"

int main()
{

    int a;
    int c = f(10);

    return c;
}
