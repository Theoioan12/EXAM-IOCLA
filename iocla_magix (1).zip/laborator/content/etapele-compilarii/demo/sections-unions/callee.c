/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

int f(int a)
{
    return a * 10;
}
