int puts(const char *);

int main(void)
{
	puts("Hello, World!\n");
	return 0;
}
