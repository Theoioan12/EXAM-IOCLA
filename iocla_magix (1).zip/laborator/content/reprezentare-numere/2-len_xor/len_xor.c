#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int my_strlen(const char *str)
{
	/* TODO */
	(void) str;

	return -1;
}

void equality_check(const char *str)
{
	/* TODO */
	(void) str;
}

int main(void)
{
	/* TODO: Test functions */

	return 0;
}

