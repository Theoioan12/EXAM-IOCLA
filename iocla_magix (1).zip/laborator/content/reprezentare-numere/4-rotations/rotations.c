#include <stdio.h>

void rotate_left(int *number, int bits)
{
	/* TODO */
	(void) number;
	(void) bits;
}

void rotate_right(int *number, int bits)
{
	/* TODO */
	(void) number;
	(void) bits;
}

int main()
{
	/* TODO: Test functions */

	return 0;
}

