#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void mirror(char *s)
{
	/* TODO */
	(void) s;
}

int main()
{
	/* TODO: Test function */

	return 0;
}

