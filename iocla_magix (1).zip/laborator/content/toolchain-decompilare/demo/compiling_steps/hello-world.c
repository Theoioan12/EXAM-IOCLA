/*
 * Author: Gabriel Mocanu <gabi.mocanu98@gmail.com>
 */

#include <stdio.h>
#define LEN 200

int main() {

//    char v[LEN];

    printf("Hello world from NAME!");
    return 0;
}
