#include <stdio.h>

int main(void)
{
	int v[] =  {1, 2, 15, 51, 53, 66, 202, 7000};
	int dest = v[2]; /* 15 */
	int start = 0;
	int end = sizeof(v) / sizeof(int) - 1;
	int mid = start + (end - start) / 2;

	/* TODO: Implement binary search */

Binary_Search:
	if (v[mid] == dest)
		goto Stop;
	if (dest < v[mid])
		goto Right_Binary_Search;
	if (dest > v[mid])
		goto Left_Binary_Search;
	
Left_Binary_Search:
	mid = start + (start - end) / 2;
	start = mid + 1;
	goto Binary_Search;

Right_Binary_Search:
	mid = start + (start - end) / 2;
	end = mid - 1;
	goto Binary_Search;

Stop:
	printf("%d\n", v[mid]);
	return 0;
}
