#include <stdio.h>

int main(void)
{
	int v[] = {4, 1, 2, -17, 15, 22, 6, 2};
	int max;
	int i, v_size;

	/* TODO: Implement finding the maximum value in the vector */
	max = v[0];
	i = 1;
	v_size = sizeof(v) / sizeof(*v);

Start:
	if (i == v_size)
		goto End;
	if (v[i] < max)
		goto Min;

Max_attr:
	max = v[i];

Min:
	i++;
	goto Start;

End:
	printf("%d\n", max);
	return 0;
}
