/* 1.

#include <stdio.h>

int main() {
    int v[] = {0xCAFEBABE, 0xDEADBEEF, 0x0B00B135, 0xBAADF00D, 0xDEADC0DE};
    unsigned char *char_ptr = (unsigned char *) &v;
    unsigned short *short_ptr = (unsigned short *) &v;
    unsigned int *int_ptr = (unsigned int *) &v;

    for (int i = 0 ; i < sizeof(v) / sizeof(*char_ptr); ++i) {
        printf("%p -> 0x%x\n", char_ptr, *char_ptr);
        ++char_ptr;
    }
    printf("-------------------------------\n");

    for (int i = 0 ; i < sizeof(v) / sizeof(*short_ptr); ++i) {
        printf("%p -> 0x%x\n", short_ptr, *short_ptr);
        ++short_ptr;
    }
    printf("-------------------------------\n");

    for (int i = 0 ; i < sizeof(v) / sizeof(*int_ptr); ++i) {
        printf("%p -> 0x%x\n", int_ptr, *int_ptr);
        ++int_ptr;
    }

    return 0;
}

2.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

char* delete_first(char *s, char *pattern) {
    char *found = strstr(s, pattern);

    if (!found) {
    	return strdup(s);
    }

    int nbefore = found - s;
    int nremoved = strlen(pattern);
    char *result = malloc(strlen(s) + 1 - nremoved);
    assert(result != NULL);

    strncpy(result, s, nbefore);
    strcpy(result + nbefore, found + nremoved);

    return result;
}

int main() {
	char *s = "Ana are mere";
	char *pattern = "re";

	printf("%s\n", delete_first(s, pattern));
	
	return 0;
}

3.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include "pixel.h"

#define GET_PIXEL(a, i ,j) (*(*(a + i) + j))

void colorToGray(Picture *pic) {
 	for (int i = 0; i < pic->height; ++i) {
		for (int j = 0; j < pic->width; ++j) {
			GET_PIXEL(pic->pix_array, i, j).R *= 0.3;
			GET_PIXEL(pic->pix_array, i, j).G *= 0.59;
			GET_PIXEL(pic->pix_array, i, j).B *= 0.11;
		}
    }
}

void swapRows(Pixel *row1, Pixel *row2, int width) {
	for (int i = 0; i < width; ++i) {
		Pixel temp = row1[i];
		row1[i] = row2[i];
		row2[i] = temp;
	}
}

void reversePic(Picture *pic) {
	for (int i = 0; i < pic->height / 2; ++i) {
		swapRows(pic->pix_array[i], pic->pix_array[pic->height - 1 - i],
				pic->height);
	}
}

int main() {
	int height, width;
	scanf("%d%d", &height, &width);
	Pixel **pix_array = generatePixelArray(height, width);
	Picture *pic = generatePicture(height, width, pix_array);

	printPicture(pic);
	printf("\n");
	colorToGray(pic);
	printPicture(pic);
	printf("\n");
	reversePic(pic);
	printPicture(pic);

	freePicture(&pic);
	freePixelArray(&pix_array, height, width);

	return 0;
}

4.
#include <stdio.h>
#include <stdlib.h>

void *find_max(void *arr, int n, size_t element_size, 
				int (*compare)(const void *, const void *)) {
	void *max_elem = arr;
	for (int i = 0; i < n; i++) {
		void *cur_element = (char *)arr + i * element_size;
		if (compare(cur_element, max_elem) > 0) {
			max_elem = cur_element;
		}
	}

	return max_elem;
}

int compare(const void *a, const void *b){
	return *(int *)a > *(int *)b ? 1 : 0;
}

int main() {
	int n;
	scanf("%d", &n);

	int *arr = malloc(n * sizeof(*arr));

	for (int i = 0 ; i < n; i++)
		scanf("%d", &arr[i]);       

	int *max_elem = (int* )find_max(arr, n, sizeof(*arr), compare);
	printf("Elementul maxim este: %d\n", *max_elem);
	
	free(arr);
	return 0;
}

7.
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>

int my_strcmp(const char *s1, const char *s2) {
	for (; *s1 == *s2 ; ++s1, ++s2){
		if (*s1 == '\0') {
		    return 0;
		}
	}

	return *(const unsigned char *) s1 - *(const unsigned char *) s2;
}

void *my_memcpy(void *dest, const void *src, size_t n) {
	unsigned char *d = (unsigned char *) dest;
	const unsigned char *s = (const unsigned char *) src;

	for (int i = 0 ; i < n ; ++i) {
		*d++ = *s++;
	}

	return dest;
}

char *my_strcpy(char *dest, const char *src) {
	char *old_dest = dest;
	while (*dest++ = *src++);

	return old_dest;
}

int main() {
	char s1[] = "Abracadabra";
	char s2[] = "Abracababra";
	char src[] = "Learn IOCLA, you must!";
	char *dest = malloc(sizeof(src));

	assert(my_strcmp(s1, s2) == strcmp(s1, s2));
	assert(my_memcpy(dest, src, sizeof(src)) == memcpy(dest, src, sizeof(src)));
	assert(my_strcpy(dest, src) == strcpy(dest, src));

	free(dest);

	return 0;
}
