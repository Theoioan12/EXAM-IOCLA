#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* delete_first(char *s, char *pattern)
{
	char *found = strstr(s, pattern);

	if (found == NULL)
		return NULL;

	char *before_pattern = found;

	char *new_string = malloc (strlen(s) - strlen(pattern));
	strncpy (new_string, s, pattern - s);

	char *after_pattern = before_pattern;
	for (int i = 0; i < strlen(pattern); i++)
		after_pattern++;
	strcat (new_string, after_pattern);

	return new_string;
}

int main(){
	char *s = "Ana are mere";
	char *pattern = "re";

	// Decomentati linia dupa ce ati implementat functia delete_first.
	printf("%s\n", delete_first(s, pattern));

	return 0;
}
