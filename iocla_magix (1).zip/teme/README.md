## Teme IOCLA 2020-2021
Sugestie pentru membrii echipei in privinta structurarii acestui folder gasiti in template-ul:
[template](https://github.com/systems-cs-pub-ro/iocla-public-template)
