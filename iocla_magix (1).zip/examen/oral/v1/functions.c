#include <stdio.h>

void invisible_func(void)
{
	printf("Someone call the police!\n");
}
