#include <stdio.h>

void invisible_func()
{
    printf("Godlike power!\n");
}
